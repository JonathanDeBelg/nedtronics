menutoggler = function(){
	this.init();
	
	this.init = function() {

	}
}
jQuery(document).ready(function($) {
  	$('#menu-toggle').on('click touchstart', function(event){
		$('body').toggleClass('main-menu-active');       
        $(this).toggleClass('active');
        $('nav.menu--main > ul > li').removeClass('open');
        event.stopImmediatePropagation();
        event.preventDefault();
    });
});

$(window).scroll(function() {
    var scroll = $(window).scrollTop();

    if (scroll >= 650) {
      $('.body.page-node-type-homepagina #page-wrapper > header #navbar').addClass('scroll');
    } else {
        $('.body.page-node-type-homepagina #page-wrapper > header #navbar').removeClass('scroll');
    }
});
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnV0b2dnbGVyLmpzIiwicmVhZHkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJidW5kbGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJtZW51dG9nZ2xlciA9IGZ1bmN0aW9uKCl7XG5cdHRoaXMuaW5pdCgpO1xuXHRcblx0dGhpcy5pbml0ID0gZnVuY3Rpb24oKSB7XG5cblx0fVxufSIsImpRdWVyeShkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oJCkge1xuICBcdCQoJyNtZW51LXRvZ2dsZScpLm9uKCdjbGljayB0b3VjaHN0YXJ0JywgZnVuY3Rpb24oZXZlbnQpe1xuXHRcdCQoJ2JvZHknKS50b2dnbGVDbGFzcygnbWFpbi1tZW51LWFjdGl2ZScpOyAgICAgICBcbiAgICAgICAgJCh0aGlzKS50b2dnbGVDbGFzcygnYWN0aXZlJyk7XG4gICAgICAgICQoJ25hdi5tZW51LS1tYWluID4gdWwgPiBsaScpLnJlbW92ZUNsYXNzKCdvcGVuJyk7XG4gICAgICAgIGV2ZW50LnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH0pO1xufSk7XG5cbiQod2luZG93KS5zY3JvbGwoZnVuY3Rpb24oKSB7XG4gICAgdmFyIHNjcm9sbCA9ICQod2luZG93KS5zY3JvbGxUb3AoKTtcblxuICAgIGlmIChzY3JvbGwgPj0gNjUwKSB7XG4gICAgICAkKCcuYm9keS5wYWdlLW5vZGUtdHlwZS1ob21lcGFnaW5hICNwYWdlLXdyYXBwZXIgPiBoZWFkZXIgI25hdmJhcicpLmFkZENsYXNzKCdzY3JvbGwnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKCcuYm9keS5wYWdlLW5vZGUtdHlwZS1ob21lcGFnaW5hICNwYWdlLXdyYXBwZXIgPiBoZWFkZXIgI25hdmJhcicpLnJlbW92ZUNsYXNzKCdzY3JvbGwnKTtcbiAgICB9XG59KTsiXX0=
